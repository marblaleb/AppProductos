package com.example.examen_marcobl.Model

data class Producto (var nombre: String, var precio: Int)