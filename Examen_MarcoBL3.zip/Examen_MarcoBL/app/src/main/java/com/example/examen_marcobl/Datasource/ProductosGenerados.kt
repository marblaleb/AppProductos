package com.example.examen1.data

import com.example.examen_marcobl.Model.Producto

object DataSource {
    val productos = arrayListOf<Producto>(
        Producto("Jamón", 120),
        Producto("Queso", 20),
        Producto("Atún", 40),
        Producto("Macarrones", 5),
        Producto("Pollo", 15),
        Producto("Mascarpone", 23),
    )
}